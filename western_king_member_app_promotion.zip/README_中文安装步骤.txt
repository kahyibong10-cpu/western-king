WESTERN KING MEMBER APP — 安装说明

文件：
- index.html：会员注册/登录、菜单、购物车、折扣、下单、个人订单记录
- admin.html：管理员订单管理和状态更新
- manifest.json、sw.js：PWA 基础文件
- firestore.rules：Firestore 安全规则

步骤 1：Firebase Console
1. 打开项目 western-king-restaurant。
2. Authentication > Get started > Sign-in method > 启用 Email/Password。
3. Firestore Database 确认数据库已建立。
4. Authentication > Settings / Authorized domains，确认你的 GitHub Pages 域名 kahyibong10-cpu.github.io 已授权（如不在列表中就添加）。
5. Firestore Database > Rules，将 firestore.rules 的内容复制进去。先把示例管理员邮箱 replace-with-your-admin-email@example.com 改成你自己的管理员 Email，再发布规则。
   同一个管理员 Email 也要在 admin.html 的 ADMIN_EMAILS 数组里改掉。

步骤 2：上传到 GitHub
把 index.html、admin.html、manifest.json、sw.js 放进现有仓库 western-king 的根目录。
不要删除你原有文件，先下载备份。确认 GitHub Pages 发布后，打开：
https://kahyibong10-cpu.github.io/western-king/

管理员页面：
https://kahyibong10-cpu.github.io/western-king/admin.html

步骤 3：测试
1. 用测试 Email 注册一个会员并登录。
2. 添加食物，填写姓名、选择堂食/外带；堂食必须填桌号。
3. 下单后，Firebase Firestore > orders 应出现一笔带有 uid 的新订单。
4. 在 admin.html 用管理员 Email 登录，尝试更新订单状态。
5. 用另一个会员账号登录，确认看不到第一个会员的订单。

重要安全说明
- 示例管理员邮箱必须替换；必须在 Firestore Rules 和 admin.html 两处使用同一个 Email。
- 不要把 Firestore Rules 设为 allow read, write: if true。
- Firebase Web config 中的 apiKey 是客户端配置，不是管理员密码；安全主要靠 Authentication 和 Firestore Rules。
- 此版本是免费测试原型，不是已审计的正式商业系统。规则目前允许已登录会员提交订单字段；正式上线前建议用 Cloud Functions/后端校验价格、折扣和订单字段，防止篡改。
- Weekend 20% 仅在星期六/日并输入 WEEKEND20 时在客户端计算。客户端优惠不能作为正式防作弊机制。
- 图片需要网络连接；图片网址失效时会自动隐藏图片。
- PWA 安装要求通过 HTTPS（GitHub Pages 可用）。此项目不会直接生成 Google Play APK。
